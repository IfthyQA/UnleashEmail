package utils;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

public class EmailLogUtil {
    private static final String LOG_FILE_PATH = "emailed_leads_log.csv";

    public static void logEmail(String timestamp, String email, String firstName, String company, String senderName) {
        File file = new File(LOG_FILE_PATH);
        boolean isNewFile = !file.exists();

        try (BufferedWriter writer = new BufferedWriter(
                new OutputStreamWriter(new FileOutputStream(file, true), StandardCharsets.UTF_8))) {

            if (isNewFile) {
                writer.write("Timestamp,Email,FirstName,Company,Sender\n");
            }
            writer.write(String.format("%s,%s,%s,%s,%s%n", timestamp, email, firstName, company, senderName));

        } catch (IOException e) {
            System.err.println("Error writing to log file: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static boolean alreadyEmailed(String email) {
        File file = new File(LOG_FILE_PATH);
        if (!file.exists()) return false;

        try {
            return Files.lines(Path.of(LOG_FILE_PATH), StandardCharsets.UTF_8)
                    .anyMatch(line -> line.contains(email));
        } catch (IOException e) {
            System.err.println("Error reading email log: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
}
