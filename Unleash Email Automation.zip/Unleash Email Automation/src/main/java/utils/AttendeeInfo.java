package utils;

public class AttendeeInfo {
    private String firstName;
    private String email;
    private String company;
    private String senderName;    

    public AttendeeInfo(String firstName, String email, String OrgName, String SenderName) {
        this.firstName = firstName;
        this.email = email;
        this.company = OrgName;
        this.senderName = SenderName;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getEmail() {
        return email;
    }

    public String getOrgName() {
        return company;
    }
    
    public String getSenderName() {
        return senderName;
    }
}
