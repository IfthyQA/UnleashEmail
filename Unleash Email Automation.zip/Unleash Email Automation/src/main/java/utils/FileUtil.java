package utils;

import java.io.File;
import java.util.Arrays;
import java.util.Comparator;

public class FileUtil {

    public static File getLatestFileFromDir(String dirPath, String extension) {
        File dir = new File(dirPath);
        File[] files = dir.listFiles((d, name) -> name.toLowerCase().endsWith(extension));

        if (files == null || files.length == 0) {
            System.out.println("No files found in directory: " + dirPath);
            return null;
        }

        Arrays.sort(files, Comparator.comparingLong(File::lastModified).reversed());
        return files[0]; // Most recently modified file
    }
}
