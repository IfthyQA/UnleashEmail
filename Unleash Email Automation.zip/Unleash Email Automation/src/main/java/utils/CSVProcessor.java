package utils;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;

public class CSVProcessor {

    // Adjust column indices as per your Excel structure
    private static final int FIRST_NAME_COLUMN_INDEX = 0;  // Assume A
    private static final int EMAIL_COLUMN_INDEX = 2;       // Assume C
    private static final int COMPANY_COLUMN_INDEX = 3; // Assume D
    private static final int SCANBY = 12;  // Assume <
    private static final int TIMESTAMP_COLUMN_INDEX = 13;  // Assume N

    public static List<AttendeeInfo> getRecentUserData(String filePath) {
        List<AttendeeInfo> users = new ArrayList<>();
        try (FileInputStream fis = new FileInputStream(new File(filePath));
             Workbook workbook = new XSSFWorkbook(fis)) {

            Sheet sheet = workbook.getSheetAt(0);
            Iterator<Row> rowIterator = sheet.iterator();
            rowIterator.next(); // Skip header row

            LocalDateTime now = LocalDateTime.now();
            LocalDateTime tenMinutesAgo  = now.minusMinutes(10);

            while (rowIterator.hasNext()) {
                Row row = rowIterator.next();

                Cell timestampCell = row.getCell(TIMESTAMP_COLUMN_INDEX);
                Cell emailCell = row.getCell(EMAIL_COLUMN_INDEX);
                Cell firstNameCell = row.getCell(FIRST_NAME_COLUMN_INDEX);
                Cell CompanyName = row.getCell(COMPANY_COLUMN_INDEX );
                Cell SenderName = row.getCell(SCANBY);

                if (timestampCell == null || emailCell == null || firstNameCell == null || CompanyName == null || SenderName == null )
                    continue;

                if (timestampCell.getCellType() == CellType.NUMERIC && DateUtil.isCellDateFormatted(timestampCell)) {
                    Date timestamp = timestampCell.getDateCellValue();
                    LocalDateTime rowTime = timestamp.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();

                    if (rowTime.isAfter(tenMinutesAgo ) && rowTime.isBefore(now)) {
                    	String email = emailCell.getStringCellValue().trim();
                    	String firstName = firstNameCell.getStringCellValue().trim();
                    	String companyName = CompanyName.getStringCellValue().trim();
                    	String senderName = SenderName.getStringCellValue().trim();


                        if (!email.isEmpty()) {
                            users.add(new AttendeeInfo(firstName, email, companyName,senderName));
                            Thread.sleep(1000); // Optional delay
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return users;
    }
}