package utils;

import com.sendgrid.*;
import com.sendgrid.helpers.mail.Mail;
import com.sendgrid.helpers.mail.objects.Email;
import com.sendgrid.helpers.mail.objects.Personalization;

import java.io.IOException;

public class SendGridMailer {

    private static final String API_KEY = "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";

    public static void sendDynamicTemplateEmail(String toEmail, String firstName, String companyName, String senderName) throws IOException {
        Email from = new Email("ijupiter@achnet.com");
        Email to = new Email(toEmail);

        Mail mail = new Mail();
        mail.setFrom(from);

        // Set the dynamic template ID from SendGrid UI
        mail.setTemplateId("d-d2c947cd16cf432da967e8528dfc1058");

        // Set dynamic content to be injected into template
        Personalization personalization = new Personalization();
        personalization.addTo(to);
        personalization.addDynamicTemplateData("first_name", firstName);
        personalization.addDynamicTemplateData("company", companyName);
        personalization.addDynamicTemplateData("Sender_Name", senderName);
        mail.addPersonalization(personalization);

        // Send email
        SendGrid sg = new SendGrid(API_KEY);
        Request request = new Request();

        try {
            request.setMethod(Method.POST);
            request.setEndpoint("mail/send");
            request.setBody(mail.build());

            Response response = sg.api(request);
            System.out.println("Status Code: " + response.getStatusCode());
            System.out.println("Response Body: " + response.getBody());
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
