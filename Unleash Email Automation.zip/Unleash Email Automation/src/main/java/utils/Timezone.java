package utils;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.TextStyle;
import java.util.Locale;

public class Timezone {
    public static void main(String[] args) {
        ZoneId zone = ZoneId.of("America/Los_Angeles"); // PST/PDT region
        ZonedDateTime now = ZonedDateTime.now(zone);

        System.out.println("Zone ID       : " + zone);
        System.out.println("Current Time  : " + now);
        System.out.println("Offset        : " + now.getOffset()); // e.g., -07:00
        System.out.println("Zone Name     : " + now.getZone().getDisplayName(TextStyle.FULL, Locale.ENGLISH));
        System.out.println("DST Active?   : " + now.getZone().getRules().isDaylightSavings(now.toInstant()));
    }
}
