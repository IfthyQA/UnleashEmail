package scheduler;

import email_Automation.UnleashDownloader;

import java.time.LocalDate;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class Scheduler {

    public static void main(String[] args) {
        ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);

        Runnable task = () -> {
            LocalDate today = LocalDate.now();
            LocalDate startDate = LocalDate.of(2025, 5, 6); // Start date: May 6th
            LocalDate endDate = LocalDate.of(2025, 5, 9);   // End date: May 9th due to utC time difference

            if (!today.isBefore(startDate) && !today.isAfter(endDate)) {
                System.out.println("Running UnleashDownloader at: " + today);
                try {
                    new UnleashDownloader().run(); // Executes the UnleashDownloader's logic
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else {
                System.out.println("Skipped (outside event days): " + today);
            }
        };

        // Schedule the task to run every 1 minutes continuously 24/7, within the date range
        scheduler.scheduleAtFixedRate(task, 0, 10, TimeUnit.MINUTES);
    }
}
