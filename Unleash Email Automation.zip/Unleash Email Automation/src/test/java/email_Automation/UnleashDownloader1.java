package email_Automation;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import BaseClass.BaseTest;
import utils.AttendeeInfo;
import utils.CSVProcessor;
import utils.FileUtil;
import utils.SendGridMailer;

import java.io.File;
import java.time.Duration;
import java.util.List;

public class UnleashDownloader1 extends BaseTest {

    @Test
    public void loginAndDownload() throws Exception {
        driver.get("https://events.unleash.ai/e/unleash-america-2025/partner-workspace/ab479519-8910-f011-aaa7-6045bd9d3cdc/leads");

        driver.findElement(By.xpath("//button[@id='onetrust-accept-btn-handler']")).click(); // Accept cookies
        Thread.sleep(3000);
        driver.findElement(By.xpath("//span[normalize-space()='Log in']")).click();

        driver.findElement(By.xpath("//input[@id='Email']")).sendKeys("neeraj@achnet.com");
        driver.findElement(By.xpath("//input[@value='VALIDATE']")).click();

        driver.findElement(By.xpath("//input[@id='Password']")).sendKeys("Rockon@123321");
        driver.findElement(By.xpath("//input[@value='Log in']")).click();

        Thread.sleep(3000);
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Home")));
        driver.findElement(By.linkText("Home")).click();

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Leads")));
        driver.findElement(By.linkText("Leads")).click();
        Thread.sleep(2000);

        driver.findElement(By.xpath("//span[@class='text']")).click(); // Download button
        Thread.sleep(10000); // Wait for download

        File latestFile = FileUtil.getLatestFileFromDir("C:\\Users\\dev\\Downloads", ".xlsx");

        if (latestFile != null) {
            List<AttendeeInfo> users = CSVProcessor.getRecentUserData(latestFile.getAbsolutePath());
            for (AttendeeInfo user : users) {
                SendGridMailer.sendDynamicTemplateEmail(user.getEmail(), user.getFirstName(), user.getOrgName(), user.getSenderName());
                Thread.sleep(1000);
            }
        } else {
            System.out.println("No XLSX file found.");
        }
    }
   }
